#6.8200 Checker

Checker for 6.8200 psets.
